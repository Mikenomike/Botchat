package com.botchat

import android.content.ContentValues
import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.os.Environment
import android.os.SystemClock
import android.provider.MediaStore
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.produceState
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ---------------------------------------------------------------- media cache

object Media {
    private lateinit var dir: File
    private val locks = HashMap<String, Mutex>()

    fun init(ctx: Context) {
        dir = File(ctx.cacheDir, "media").also { it.mkdirs() }
    }

    private fun fileFor(unique: String) = File(dir, unique.replace(Regex("[^A-Za-z0-9_-]"), "_"))

    fun cached(unique: String): File? =
        fileFor(unique).takeIf { it.exists() && it.length() > 0 }

    suspend fun get(fileId: String, unique: String): File {
        cached(unique)?.let { return it }
        val s = Repo.session.value ?: throw IOException("not signed in")
        val mutex = synchronized(locks) { locks.getOrPut(unique) { Mutex() } }
        return mutex.withLock {
            cached(unique) ?: fileFor(unique).also { Api.download(s, fileId, it) }
        }
    }

    fun clear() {
        dir.deleteRecursively()
        dir.mkdirs()
    }
}

sealed interface FState {
    object Loading : FState
    class Ready(val file: File) : FState
    class Failed(val msg: String) : FState
}

@Composable
fun rememberFile(fileId: String, unique: String): State<FState> =
    produceState<FState>(
        initialValue = Media.cached(unique)?.let { FState.Ready(it) } ?: FState.Loading,
        fileId, unique
    ) {
        if (value !is FState.Ready) {
            value = try {
                FState.Ready(Media.get(fileId, unique))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                FState.Failed(e.message ?: "error")
            }
        }
    }

// ------------------------------------------------------------------ downloads

object Files {
    fun saveToDownloads(ctx: Context, src: File, name: String, mime: String): Boolean {
        return try {
            val cv = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                ?: return false
            ctx.contentResolver.openOutputStream(uri)?.use { o ->
                src.inputStream().use { it.copyTo(o) }
            } ?: return false
            true
        } catch (e: Exception) {
            false
        }
    }
}

// ------------------------------------------------------------- voice playback

object Player {
    private var mp: MediaPlayer? = null
    val current = MutableStateFlow<String?>(null)

    fun toggle(id: String, file: File) {
        if (current.value == id) {
            stop()
            return
        }
        stop()
        val p = MediaPlayer()
        try {
            p.setDataSource(file.absolutePath)
            p.setOnCompletionListener { stop() }
            p.prepare()
            p.start()
            mp = p
            current.value = id
        } catch (e: Exception) {
            p.release()
        }
    }

    fun stop() {
        try {
            mp?.release()
        } catch (e: Exception) {
        }
        mp = null
        current.value = null
    }

    fun position(): Int = try { mp?.currentPosition ?: 0 } catch (e: Exception) { 0 }
    fun duration(): Int = try { mp?.duration ?: 0 } catch (e: Exception) { 0 }
}

// -------------------------------------------------------------- voice recording

/** Records OGG/Opus, the format Telegram's sendVoice expects (needs Android 10+). */
class Recorder(private val ctx: Context) {
    private var rec: MediaRecorder? = null
    private var file: File? = null
    private var t0 = 0L

    fun start(): Boolean {
        val f = File(ctx.cacheDir, "voice_${System.currentTimeMillis()}.ogg")
        @Suppress("DEPRECATION")
        val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()
        return try {
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.OGG)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.OPUS)
            r.setAudioChannels(1)
            r.setAudioSamplingRate(48000)
            r.setAudioEncodingBitRate(32000)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            rec = r
            file = f
            t0 = SystemClock.elapsedRealtime()
            true
        } catch (e: Exception) {
            try {
                r.release()
            } catch (ignored: Exception) {
            }
            f.delete()
            false
        }
    }

    fun elapsedSec(): Int = if (rec == null) 0 else ((SystemClock.elapsedRealtime() - t0) / 1000).toInt()

    /** Stops recording. Returns the file and its length in seconds, or null when discarded/too short. */
    fun stop(keep: Boolean): Pair<File, Int>? {
        val r = rec ?: return null
        val f = file ?: return null
        val secs = elapsedSec()
        rec = null
        file = null
        try {
            r.stop()
        } catch (e: Exception) {
            r.release()
            f.delete()
            return null
        }
        r.release()
        if (!keep) {
            f.delete()
            return null
        }
        return f to secs
    }
}

// ------------------------------------------------------------------ formatting

fun fmtTime(ts: Long): String =
    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(ts))

fun fmtChatTime(ts: Long): String {
    if (ts <= 0) return ""
    val now = Calendar.getInstance()
    val then = Calendar.getInstance().apply { timeInMillis = ts }
    val sameDay = now.get(Calendar.YEAR) == then.get(Calendar.YEAR) &&
        now.get(Calendar.DAY_OF_YEAR) == then.get(Calendar.DAY_OF_YEAR)
    return SimpleDateFormat(if (sameDay) "HH:mm" else "dd/MM", Locale.getDefault()).format(Date(ts))
}

fun fmtDur(sec: Int): String = "%d:%02d".format(sec / 60, sec % 60)

fun fmtSize(b: Long): String = when {
    b <= 0 -> ""
    b < 1024 * 1024 -> "%.0f KB".format(b / 1024.0)
    else -> "%.1f MB".format(b / 1024.0 / 1024.0)
}
