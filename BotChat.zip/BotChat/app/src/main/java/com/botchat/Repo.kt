package com.botchat

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

enum class LoginResult { OK, INVALID, NETWORK }

/** App state: session, polling, sending. Lives for the whole process. */
object Repo {
    private lateinit var app: Context
    private lateinit var prefs: SharedPreferences
    lateinit var db: Db
        private set

    val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /** Bumped whenever the database changes; screens re-query on it. */
    val tick = MutableStateFlow(0)
    val session = MutableStateFlow<Session?>(null)
    val busy = MutableStateFlow(0)
    val pollError = MutableStateFlow<String?>(null)
    val errors = MutableSharedFlow<String>(extraBufferCapacity = 8)

    @Volatile
    var openChat = 0L

    fun init(ctx: Context) {
        app = ctx.applicationContext
        prefs = app.getSharedPreferences("bot", Context.MODE_PRIVATE)
        db = Db(app)
        Media.init(app)
        val t = prefs.getString("token", null)
        if (t != null) {
            session.value = Session(
                t,
                prefs.getString("base", DEFAULT_BASE) ?: DEFAULT_BASE,
                prefs.getString("name", "") ?: "",
                prefs.getString("username", "") ?: "",
            )
        }
    }

    private fun str(id: Int) = app.getString(id)

    // ---------------------------------------------------------------- login

    suspend fun login(token: String, base: String): LoginResult {
        return try {
            val me = Api.call(token, base, "getMe").getJSONObject("result")
            val old = prefs.getString("token", null)
            if (old != null && old != token) wipeLocal()
            val name = me.optString("first_name")
            val username = me.optString("username")
            prefs.edit().putString("token", token).putString("base", base)
                .putString("name", name).putString("username", username).apply()
            session.value = Session(token, base, name, username)
            LoginResult.OK
        } catch (e: CancellationException) {
            throw e
        } catch (e: ApiError) {
            LoginResult.INVALID
        } catch (e: Exception) {
            LoginResult.NETWORK
        }
    }

    private fun wipeLocal() {
        db.wipe()
        Media.clear()
        prefs.edit().remove("offset").apply()
    }

    fun logout() {
        session.value = null
        pollError.value = null
        scope.launch {
            wipeLocal()
            prefs.edit().clear().apply()
            tick.update { it + 1 }
        }
    }

    // -------------------------------------------------------------- polling

    suspend fun poll(s: Session) {
        var backoff = 1000L
        while (true) {
            try {
                val offset = prefs.getLong("offset", 0)
                val r = Api.call(
                    s, "getUpdates",
                    mapOf(
                        "offset" to offset.toString(),
                        "timeout" to "30",
                        "allowed_updates" to "[\"message\",\"edited_message\",\"channel_post\",\"edited_channel_post\"]",
                    )
                )
                pollError.value = null
                backoff = 1000
                val arr = r.getJSONArray("result")
                if (arr.length() > 0) {
                    var next = offset
                    withContext(Dispatchers.IO) {
                        for (i in 0 until arr.length()) {
                            val u = arr.getJSONObject(i)
                            next = u.getLong("update_id") + 1
                            try {
                                handleUpdate(u)
                            } catch (e: Exception) {
                                // skip a malformed update instead of blocking the queue
                            }
                        }
                    }
                    prefs.edit().putLong("offset", next).apply()
                    tick.update { it + 1 }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: ApiError) {
                pollError.value = when (e.code) {
                    409 -> "conflict"
                    401 -> "auth"
                    else -> "net"
                }
                delay(5000)
            } catch (e: Exception) {
                pollError.value = "net"
                delay(backoff)
                backoff = minOf(backoff * 2, 15000)
            }
        }
    }

    private fun handleUpdate(u: JSONObject) {
        for (key in listOf("message", "channel_post", "edited_message", "edited_channel_post")) {
            val m = u.optJSONObject(key) ?: continue
            val edited = key.startsWith("edited")
            val p = parseMessage(m, false)
            db.save(p, unread = p.msg.chatId != openChat, isNew = !edited)
            if (p.msg.kind == "sticker") db.saveSticker(p.msg)
        }
    }

    // -------------------------------------------------------------- sending

    private fun saveOut(r: JSONObject) {
        val p = parseMessage(r.getJSONObject("result"), true)
        db.save(p, unread = false, isNew = true)
        if (p.msg.kind == "sticker") db.saveSticker(p.msg)
        tick.update { it + 1 }
    }

    private fun launchSend(block: suspend (Session) -> Unit) {
        val s = session.value ?: return
        scope.launch {
            busy.update { it + 1 }
            try {
                block(s)
            } catch (e: CancellationException) {
                throw e
            } catch (e: ApiError) {
                errors.emit(e.message ?: str(R.string.err_network))
            } catch (e: Exception) {
                errors.emit(str(R.string.err_network))
            } finally {
                busy.update { it - 1 }
            }
        }
    }

    fun sendText(chatId: Long, text: String) = launchSend { s ->
        for (part in text.chunked(4096)) {
            saveOut(Api.call(s, "sendMessage", mapOf("chat_id" to chatId.toString(), "text" to part)))
        }
    }

    fun sendStickerId(chatId: Long, fileId: String) = launchSend { s ->
        saveOut(Api.call(s, "sendSticker", mapOf("chat_id" to chatId.toString(), "sticker" to fileId)))
    }

    fun sendVoice(chatId: Long, file: File, seconds: Int) = launchSend { s ->
        try {
            saveOut(
                Api.call(
                    s, "sendVoice",
                    mapOf("chat_id" to chatId.toString(), "duration" to seconds.toString()),
                    Upload("voice", file, "voice.ogg", "audio/ogg")
                )
            )
        } finally {
            file.delete()
        }
    }

    /** Sends a picked file: photo / video / GIF / document (or a .webp as a sticker). */
    fun sendUri(chatId: Long, uri: Uri, asDocument: Boolean = false, asSticker: Boolean = false) =
        launchSend { s ->
            val cr = app.contentResolver
            var name = "file"
            cr.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (ni >= 0) name = c.getString(ni) ?: name
                }
            }
            val mime = cr.getType(uri) ?: "application/octet-stream"
            val tmp = File(app.cacheDir, "up_${System.nanoTime()}")
            try {
                val input = cr.openInputStream(uri) ?: throw java.io.IOException("cannot open file")
                input.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                if (tmp.length() > 50L * 1024 * 1024) {
                    errors.emit(str(R.string.err_too_big))
                    return@launchSend
                }
                val chat = mapOf("chat_id" to chatId.toString())
                suspend fun go(method: String, field: String, extra: Map<String, String> = emptyMap()) {
                    saveOut(Api.call(s, method, chat + extra, Upload(field, tmp, name, mime)))
                }
                when {
                    asSticker -> go("sendSticker", "sticker")
                    asDocument -> go("sendDocument", "document")
                    mime == "image/gif" -> go("sendAnimation", "animation")
                    mime.startsWith("image/") -> try {
                        go("sendPhoto", "photo")
                    } catch (e: ApiError) {
                        if (e.code == 400) go("sendDocument", "document") else throw e
                    }
                    mime.startsWith("video/") -> go("sendVideo", "video", mapOf("supports_streaming" to "true"))
                    else -> go("sendDocument", "document")
                }
            } finally {
                tmp.delete()
            }
        }

    // ----------------------------------------------------------- misc calls

    suspend fun addChat(input: String): Boolean {
        val s = session.value ?: return false
        var id = input.trim()
        if (id.isEmpty()) return false
        if (id.toLongOrNull() == null && !id.startsWith("@")) id = "@$id"
        return try {
            val c = Api.call(s, "getChat", mapOf("chat_id" to id)).getJSONObject("result")
            withContext(Dispatchers.IO) {
                db.upsertChat(c.getLong("id"), chatTitle(c), c.optString("username"), c.optString("type"))
            }
            tick.update { it + 1 }
            true
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            false
        }
    }

    fun removeWebhook() {
        val s = session.value ?: return
        scope.launch {
            try {
                Api.call(s, "deleteWebhook", mapOf("drop_pending_updates" to "false"))
                pollError.value = null
                errors.emit(str(R.string.webhook_removed))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                errors.emit(e.message ?: str(R.string.err_network))
            }
        }
    }
}
