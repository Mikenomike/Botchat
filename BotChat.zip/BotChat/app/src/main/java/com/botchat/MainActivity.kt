package com.botchat

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.foundation.layout.fillMaxSize
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Fetch updates only while the app is on screen.
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                Repo.session.collectLatest { s -> if (s != null) Repo.poll(s) }
            }
        }
        setContent { AppTheme { Root() } }
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme()) {
        darkColorScheme(
            primary = Color(0xFF5BB8F0),
            primaryContainer = Color(0xFF1F4F6E),
            onPrimaryContainer = Color(0xFFFFFFFF),
        )
    } else {
        lightColorScheme(
            primary = Color(0xFF2AABEE),
            primaryContainer = Color(0xFFD5EEFB),
            onPrimaryContainer = Color(0xFF111111),
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun Root() {
    val session by Repo.session.collectAsState()
    var chatId by rememberSaveable { mutableStateOf<Long?>(null) }
    val ctx = LocalContext.current

    LaunchedEffect(Unit) {
        Repo.errors.collect { Toast.makeText(ctx, it, Toast.LENGTH_LONG).show() }
    }
    // Back to the login screen state if the user signs out while a chat is open.
    LaunchedEffect(session) { if (session == null) chatId = null }

    // Keep the layout left-to-right (outgoing bubbles on the right); text still aligns by its own script.
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            if (session == null) {
                LoginScreen()
            } else {
                val id = chatId
                if (id == null) {
                    ChatListScreen(onOpen = { chatId = it })
                } else {
                    BackHandler { chatId = null }
                    ChatScreen(id) { chatId = null }
                }
            }
        }
    }
}
