package com.botchat

import android.app.Application

class BotChatApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Repo.init(this)
    }
}
