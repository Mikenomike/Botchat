@file:OptIn(ExperimentalMaterial3Api::class)

package com.botchat

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

// ------------------------------------------------------------------ chat screen

@Composable
fun ChatScreen(chatId: Long, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val tick by Repo.tick.collectAsState()
    val busy by Repo.busy.collectAsState()
    var chat by remember { mutableStateOf<Chat?>(null) }
    var msgs by remember { mutableStateOf(emptyList<Msg>()) }
    var text by rememberSaveable { mutableStateOf("") }
    var attachMenu by remember { mutableStateOf(false) }
    var viewing by remember { mutableStateOf<Msg?>(null) }
    var showStickers by remember { mutableStateOf(false) }
    var recording by remember { mutableStateOf(false) }
    var elapsed by remember { mutableStateOf(0) }
    val recorder = remember { Recorder(ctx) }

    LaunchedEffect(tick, chatId) {
        val (c, m) = withContext(Dispatchers.IO) {
            Repo.db.markRead(chatId)
            Repo.db.chat(chatId) to Repo.db.messages(chatId, 400)
        }
        chat = c
        msgs = m
    }
    DisposableEffect(chatId) {
        Repo.openChat = chatId
        onDispose {
            Repo.openChat = 0
            Player.stop()
            recorder.stop(false)
        }
    }
    LaunchedEffect(recording) {
        while (recording) {
            elapsed = recorder.elapsedSec()
            delay(250)
        }
    }

    val pickMedia = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) Repo.sendUri(chatId, uri)
    }
    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) Repo.sendUri(chatId, uri, asDocument = true)
    }
    val pickSticker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) Repo.sendUri(chatId, uri, asSticker = true)
    }
    fun startRecording() {
        if (recorder.start()) {
            elapsed = 0
            recording = true
        }
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startRecording() else Toast.makeText(ctx, R.string.mic_denied, Toast.LENGTH_LONG).show()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null) }
                },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Avatar(chatId, chat?.title.orEmpty(), 36)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(chat?.title.orEmpty(), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
                            val u = chat?.username.orEmpty()
                            if (u.isNotEmpty()) Text("@$u", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                },
            )
        },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (busy > 0) LinearProgressIndicator(Modifier.fillMaxWidth())

            val showSender = chat?.type.let { it != null && it != "private" }
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), reverseLayout = true) {
                items(msgs, key = { it.rowId }) { m ->
                    MessageBubble(m, showSender) { viewing = it }
                }
            }

            // ------------------------------------------------------ input bar
            Surface(tonalElevation = 3.dp) {
                if (recording) {
                    Row(Modifier.fillMaxWidth().padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { recorder.stop(false); recording = false }) { Text("🗑", fontSize = 22.sp) }
                        Text(
                            "● " + stringResource(R.string.recording) + "  " + fmtDur(elapsed),
                            Modifier.weight(1f),
                            color = MaterialTheme.colorScheme.error,
                        )
                        IconButton(onClick = {
                            val r = recorder.stop(true)
                            recording = false
                            if (r != null) {
                                if (r.second >= 1) Repo.sendVoice(chatId, r.first, r.second) else r.first.delete()
                            }
                        }) { Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, tint = MaterialTheme.colorScheme.primary) }
                    }
                } else {
                    Row(Modifier.fillMaxWidth().padding(6.dp), verticalAlignment = Alignment.Bottom) {
                        Box {
                            IconButton(onClick = { attachMenu = true }) { Text("📎", fontSize = 22.sp) }
                            DropdownMenu(expanded = attachMenu, onDismissRequest = { attachMenu = false }) {
                                DropdownMenuItem(
                                    text = { Text("🖼  " + stringResource(R.string.attach_gallery)) },
                                    onClick = {
                                        attachMenu = false
                                        pickMedia.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
                                    },
                                )
                                DropdownMenuItem(
                                    text = { Text("📄  " + stringResource(R.string.attach_file)) },
                                    onClick = { attachMenu = false; pickFile.launch(arrayOf("*/*")) },
                                )
                                DropdownMenuItem(
                                    text = { Text("🙂  " + stringResource(R.string.attach_sticker)) },
                                    onClick = { attachMenu = false; showStickers = true },
                                )
                            }
                        }
                        OutlinedTextField(
                            value = text,
                            onValueChange = { text = it },
                            placeholder = { Text(stringResource(R.string.message_hint)) },
                            maxLines = 5,
                            modifier = Modifier.weight(1f),
                        )
                        if (text.isBlank()) {
                            IconButton(onClick = {
                                if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
                                    PackageManager.PERMISSION_GRANTED
                                ) startRecording() else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                            }) { Text("🎙", fontSize = 22.sp) }
                        } else {
                            IconButton(onClick = {
                                Repo.sendText(chatId, text.trim())
                                text = ""
                            }) { Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, tint = MaterialTheme.colorScheme.primary) }
                        }
                    }
                }
            }
        }
    }

    viewing?.let { Viewer(it) { viewing = null } }
    if (showStickers) {
        StickerTray(
            onPick = { Repo.sendStickerId(chatId, it.fileId); showStickers = false },
            onFile = { showStickers = false; pickSticker.launch(arrayOf("image/webp")) },
            onClose = { showStickers = false },
        )
    }
}

// ---------------------------------------------------------------------- bubbles

@Composable
fun MessageBubble(m: Msg, showSender: Boolean, onView: (Msg) -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val isSticker = m.kind == "sticker"
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 2.dp),
        horizontalArrangement = if (m.out) Arrangement.End else Arrangement.Start,
    ) {
        Surface(
            color = if (isSticker) Color.Transparent else if (m.out) scheme.primaryContainer else scheme.surfaceVariant,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.widthIn(max = 300.dp),
        ) {
            Column(Modifier.padding(if (isSticker) 0.dp else 8.dp)) {
                if (showSender && !m.out && m.sender.isNotEmpty()) {
                    Text(m.sender, color = scheme.primary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                when (m.kind) {
                    "photo" -> PhotoView(m, onView)
                    "video" -> VideoThumb(m, onView)
                    "animation" -> AnimationView(m, onView)
                    "voice" -> VoiceView(m)
                    "sticker" -> StickerView(m)
                    "document" -> DocumentView(m)
                    "other" -> Text(stringResource(R.string.unsupported), fontSize = 14.sp, color = scheme.onSurfaceVariant)
                }
                if (m.text.isNotEmpty() && !isSticker) {
                    Text(m.text, fontSize = 16.sp)
                }
                Text(
                    fmtTime(m.ts),
                    fontSize = 11.sp,
                    color = scheme.onSurfaceVariant,
                    modifier = Modifier.align(Alignment.End).padding(start = 24.dp, top = 2.dp),
                )
            }
        }
    }
}

@Composable
fun FileImage(
    fileId: String,
    unique: String,
    modifier: Modifier,
    scale: ContentScale = ContentScale.Crop,
) {
    val st by rememberFile(fileId, unique)
    when (val s = st) {
        is FState.Ready -> AsyncImage(model = s.file, contentDescription = null, contentScale = scale, modifier = modifier)
        is FState.Failed -> Box(modifier.background(Color(0x22888888)), contentAlignment = Alignment.Center) { Text("⚠️") }
        FState.Loading -> Box(modifier.background(Color(0x22888888)), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
        }
    }
}

private fun ratio(m: Msg): Float =
    if (m.w > 0 && m.h > 0) (m.w.toFloat() / m.h).coerceIn(0.5f, 2f) else 1.33f

@Composable
fun PhotoView(m: Msg, onView: (Msg) -> Unit) {
    FileImage(
        m.thumbId, m.thumbUnique,
        Modifier.width(240.dp).aspectRatio(ratio(m)).clip(RoundedCornerShape(8.dp)).clickable { onView(m) },
    )
}

@Composable
fun VideoThumb(m: Msg, onView: (Msg) -> Unit) {
    Box(
        Modifier.width(240.dp).aspectRatio(ratio(m)).clip(RoundedCornerShape(8.dp)).clickable { onView(m) },
        contentAlignment = Alignment.Center,
    ) {
        if (m.thumbId.isNotEmpty()) {
            FileImage(m.thumbId, m.thumbUnique, Modifier.fillMaxSize())
        } else {
            Box(Modifier.fillMaxSize().background(Color(0xFF444444)))
        }
        Box(Modifier.size(48.dp).clip(CircleShape).background(Color(0x99000000)), contentAlignment = Alignment.Center) {
            Text("▶", color = Color.White, fontSize = 22.sp)
        }
        if (m.duration > 0) {
            Text(
                fmtDur(m.duration),
                color = Color.White,
                fontSize = 12.sp,
                modifier = Modifier.align(Alignment.BottomStart).padding(6.dp)
                    .background(Color(0x99000000), RoundedCornerShape(6.dp)).padding(horizontal = 6.dp),
            )
        }
    }
}

@Composable
fun AnimationView(m: Msg, onView: (Msg) -> Unit) {
    val st by rememberFile(m.fileId, m.uniqueId)
    Box(
        Modifier.width(240.dp).aspectRatio(ratio(m)).clip(RoundedCornerShape(8.dp)).clickable { onView(m) },
        contentAlignment = Alignment.Center,
    ) {
        when (val s = st) {
            is FState.Ready -> VideoPlayer(s.file, controls = false, loop = true, modifier = Modifier.fillMaxSize())
            is FState.Failed -> Text("⚠️")
            FState.Loading -> CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
        }
    }
}

@Composable
fun VoiceView(m: Msg) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val current by Player.current.collectAsState()
    val playing = current == m.uniqueId
    var loading by remember { mutableStateOf(false) }
    var pos by remember { mutableStateOf(0f) }

    LaunchedEffect(playing) {
        if (!playing) {
            pos = 0f
        } else {
            while (true) {
                val d = Player.duration()
                pos = if (d > 0) Player.position().toFloat() / d else 0f
                delay(150)
            }
        }
    }

    Row(Modifier.width(220.dp).padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(40.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary).clickable(enabled = !loading) {
                scope.launch {
                    loading = true
                    try {
                        Player.toggle(m.uniqueId, Media.get(m.fileId, m.uniqueId))
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        Toast.makeText(ctx, R.string.err_download, Toast.LENGTH_LONG).show()
                    } finally {
                        loading = false
                    }
                }
            },
            contentAlignment = Alignment.Center,
        ) {
            if (loading) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White)
            else Text(if (playing) "⏹" else "▶", color = Color.White, fontSize = 18.sp)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            LinearProgressIndicator(progress = { pos }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.size(4.dp))
            val label = if (m.name.isNotEmpty()) m.name else fmtDur(m.duration)
            Text(label, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun StickerView(m: Msg) {
    val box = Modifier.size(160.dp)
    when {
        m.stickerType == "static" -> FileImage(m.fileId, m.uniqueId, box, ContentScale.Fit)
        m.thumbId.isNotEmpty() -> FileImage(m.thumbId, m.thumbUnique, box, ContentScale.Fit)
        else -> Box(box, contentAlignment = Alignment.Center) { Text(m.text, fontSize = 64.sp) }
    }
}

@Composable
fun DocumentView(m: Msg) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var loading by remember { mutableStateOf(false) }
    Row(
        Modifier.width(240.dp).clickable(enabled = !loading) {
            scope.launch {
                loading = true
                try {
                    val f = Media.get(m.fileId, m.uniqueId)
                    val name = m.name.ifEmpty { "file_${m.uniqueId}" }
                    val ok = withContext(Dispatchers.IO) {
                        Files.saveToDownloads(ctx, f, name, m.mime.ifEmpty { "application/octet-stream" })
                    }
                    Toast.makeText(ctx, if (ok) R.string.saved else R.string.err_download, Toast.LENGTH_SHORT).show()
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Toast.makeText(ctx, R.string.err_download, Toast.LENGTH_LONG).show()
                } finally {
                    loading = false
                }
            }
        },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (loading) CircularProgressIndicator(Modifier.size(28.dp), strokeWidth = 2.dp) else Text("📄", fontSize = 28.sp)
        Spacer(Modifier.width(10.dp))
        Column {
            Text(m.name.ifEmpty { stringResource(R.string.k_file) }, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
            Text(fmtSize(m.size), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ----------------------------------------------------------------------- video

@Composable
fun VideoPlayer(file: File, controls: Boolean, loop: Boolean, modifier: Modifier = Modifier) {
    AndroidView(
        modifier = modifier,
        factory = { c ->
            VideoView(c).apply {
                setVideoPath(file.absolutePath)
                if (controls) {
                    val mc = MediaController(c)
                    mc.setAnchorView(this)
                    setMediaController(mc)
                }
                setOnPreparedListener { mp ->
                    mp.isLooping = loop
                    if (!controls) mp.setVolume(0f, 0f)
                    start()
                }
            }
        },
        onRelease = { it.stopPlayback() },
    )
}

// ---------------------------------------------------------------------- viewer

@Composable
fun Viewer(m: Msg, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val st by rememberFile(m.fileId, m.uniqueId)
    val scope = rememberCoroutineScope()

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            when (val s = st) {
                is FState.Ready -> when (m.kind) {
                    "photo" -> ZoomImage(s.file)
                    "video" -> VideoPlayer(s.file, controls = true, loop = false, modifier = Modifier.fillMaxSize())
                    else -> VideoPlayer(s.file, controls = false, loop = true, modifier = Modifier.fillMaxSize())
                }
                is FState.Failed -> Text(
                    stringResource(R.string.err_download),
                    color = Color.White,
                    modifier = Modifier.align(Alignment.Center).padding(24.dp),
                )
                FState.Loading -> CircularProgressIndicator(Modifier.align(Alignment.Center), color = Color.White)
            }
            Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton(onClick = onClose) { Text("✕", color = Color.White, fontSize = 24.sp) }
                val ready = st as? FState.Ready
                if (ready != null) {
                    TextButton(onClick = {
                        scope.launch {
                            val (name, mime) = when (m.kind) {
                                "photo" -> "photo_${m.uniqueId}.jpg" to "image/jpeg"
                                else -> "${m.kind}_${m.uniqueId}.mp4" to "video/mp4"
                            }
                            val ok = withContext(Dispatchers.IO) { Files.saveToDownloads(ctx, ready.file, name, mime) }
                            Toast.makeText(ctx, if (ok) R.string.saved else R.string.err_download, Toast.LENGTH_SHORT).show()
                        }
                    }) { Text(stringResource(R.string.save), color = Color.White) }
                }
            }
        }
    }
}

@Composable
fun ZoomImage(file: File) {
    var scale by remember { mutableStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    AsyncImage(
        model = file,
        contentDescription = null,
        contentScale = ContentScale.Fit,
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(1f, 5f)
                    offset = if (scale <= 1f) Offset.Zero else offset + pan
                }
            }
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                translationX = offset.x
                translationY = offset.y
            },
    )
}

// --------------------------------------------------------------------- stickers

@Composable
fun StickerTray(onPick: (Sticker) -> Unit, onFile: () -> Unit, onClose: () -> Unit) {
    val tick by Repo.tick.collectAsState()
    var list by remember { mutableStateOf(emptyList<Sticker>()) }
    LaunchedEffect(tick) { list = withContext(Dispatchers.IO) { Repo.db.stickers() } }

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(stringResource(R.string.stickers_title)) },
        text = {
            if (list.isEmpty()) {
                Text(stringResource(R.string.stickers_empty), color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                LazyVerticalGrid(GridCells.Fixed(4), modifier = Modifier.heightIn(max = 360.dp)) {
                    gridItems(list, key = { it.uniqueId }) { st ->
                        Box(Modifier.padding(4.dp).size(72.dp).clickable { onPick(st) }, contentAlignment = Alignment.Center) {
                            if (st.type == "static" || st.thumbId.isEmpty()) {
                                FileImage(st.fileId, st.uniqueId, Modifier.fillMaxSize(), ContentScale.Fit)
                            } else {
                                FileImage(st.thumbId, st.thumbUnique, Modifier.fillMaxSize(), ContentScale.Fit)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onFile) { Text(stringResource(R.string.sticker_send_file)) } },
        dismissButton = { TextButton(onClick = onClose) { Text(stringResource(R.string.close)) } },
    )
}
