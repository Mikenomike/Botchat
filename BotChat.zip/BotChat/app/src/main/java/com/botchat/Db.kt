package com.botchat

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Chat(
    val id: Long,
    val title: String,
    val username: String,
    val type: String,
    val lastKind: String,
    val lastText: String,
    val lastTs: Long,
    val unread: Int,
)

data class Sticker(
    val uniqueId: String,
    val fileId: String,
    val thumbId: String,
    val thumbUnique: String,
    val type: String,
)

private fun Cursor.s(i: Int): String = getString(i) ?: ""

class Db(ctx: Context) : SQLiteOpenHelper(ctx, "botchat.db", null, 1) {

    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL(
            "CREATE TABLE chats(id INTEGER PRIMARY KEY, title TEXT, username TEXT, type TEXT, " +
                "last_kind TEXT, last_text TEXT, last_ts INTEGER, unread INTEGER DEFAULT 0)"
        )
        d.execSQL(
            "CREATE TABLE messages(id INTEGER PRIMARY KEY AUTOINCREMENT, chat_id INTEGER, msg_id INTEGER, " +
                "ts INTEGER, outgoing INTEGER, sender TEXT, kind TEXT, text TEXT, file_id TEXT, unique_id TEXT, " +
                "thumb_id TEXT, thumb_unique TEXT, name TEXT, mime TEXT, duration INTEGER, w INTEGER, h INTEGER, " +
                "size INTEGER, sticker_type TEXT, UNIQUE(chat_id, msg_id) ON CONFLICT REPLACE)"
        )
        d.execSQL("CREATE INDEX idx_messages ON messages(chat_id, ts)")
        d.execSQL(
            "CREATE TABLE stickers(unique_id TEXT PRIMARY KEY, file_id TEXT, thumb_id TEXT, " +
                "thumb_unique TEXT, sticker_type TEXT, used INTEGER)"
        )
    }

    override fun onUpgrade(d: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    @Synchronized
    fun save(p: Parsed, unread: Boolean, isNew: Boolean) {
        val d = writableDatabase
        val m = p.msg
        d.beginTransaction()
        try {
            val cv = ContentValues()
            cv.put("chat_id", m.chatId)
            cv.put("msg_id", m.msgId)
            cv.put("ts", m.ts)
            cv.put("outgoing", if (m.out) 1 else 0)
            cv.put("sender", m.sender)
            cv.put("kind", m.kind)
            cv.put("text", m.text)
            cv.put("file_id", m.fileId)
            cv.put("unique_id", m.uniqueId)
            cv.put("thumb_id", m.thumbId)
            cv.put("thumb_unique", m.thumbUnique)
            cv.put("name", m.name)
            cv.put("mime", m.mime)
            cv.put("duration", m.duration)
            cv.put("w", m.w)
            cv.put("h", m.h)
            cv.put("size", m.size)
            cv.put("sticker_type", m.stickerType)
            d.insert("messages", null, cv)

            d.execSQL(
                "INSERT OR IGNORE INTO chats(id,title,username,type,last_kind,last_text,last_ts,unread) " +
                    "VALUES(?,?,?,?,?,?,?,0)",
                arrayOf<Any?>(m.chatId, p.chatTitle, p.chatUsername, p.chatType, m.kind, m.text.take(120), m.ts)
            )
            d.execSQL(
                "UPDATE chats SET title=?, username=?, type=? WHERE id=?",
                arrayOf<Any?>(p.chatTitle, p.chatUsername, p.chatType, m.chatId)
            )
            if (isNew) {
                d.execSQL(
                    "UPDATE chats SET last_kind=?, last_text=?, last_ts=?, unread=unread+? WHERE id=?",
                    arrayOf<Any?>(m.kind, m.text.take(120), m.ts, if (unread) 1 else 0, m.chatId)
                )
            }
            d.setTransactionSuccessful()
        } finally {
            d.endTransaction()
        }
    }

    @Synchronized
    fun upsertChat(id: Long, title: String, username: String, type: String) {
        val d = writableDatabase
        d.execSQL(
            "INSERT OR IGNORE INTO chats(id,title,username,type,last_kind,last_text,last_ts,unread) " +
                "VALUES(?,?,?,?,'text','',?,0)",
            arrayOf<Any?>(id, title, username, type, System.currentTimeMillis())
        )
        d.execSQL(
            "UPDATE chats SET title=?, username=?, type=? WHERE id=?",
            arrayOf<Any?>(title, username, type, id)
        )
    }

    private fun readChat(c: Cursor) = Chat(
        id = c.getLong(0), title = c.s(1), username = c.s(2), type = c.s(3),
        lastKind = c.s(4), lastText = c.s(5), lastTs = c.getLong(6), unread = c.getInt(7),
    )

    private val chatCols = "id,title,username,type,last_kind,last_text,last_ts,unread"

    @Synchronized
    fun chats(): List<Chat> =
        readableDatabase.rawQuery("SELECT $chatCols FROM chats ORDER BY last_ts DESC", null).use { c ->
            buildList { while (c.moveToNext()) add(readChat(c)) }
        }

    @Synchronized
    fun chat(id: Long): Chat? =
        readableDatabase.rawQuery("SELECT $chatCols FROM chats WHERE id=?", arrayOf(id.toString())).use { c ->
            if (c.moveToFirst()) readChat(c) else null
        }

    @Synchronized
    fun messages(chatId: Long, limit: Int): List<Msg> =
        readableDatabase.rawQuery(
            "SELECT id,chat_id,msg_id,ts,outgoing,sender,kind,text,file_id,unique_id,thumb_id,thumb_unique," +
                "name,mime,duration,w,h,size,sticker_type FROM messages WHERE chat_id=? " +
                "ORDER BY ts DESC, id DESC LIMIT ?",
            arrayOf(chatId.toString(), limit.toString())
        ).use { c ->
            buildList {
                while (c.moveToNext()) {
                    add(
                        Msg(
                            rowId = c.getLong(0), chatId = c.getLong(1), msgId = c.getLong(2), ts = c.getLong(3),
                            out = c.getInt(4) == 1, sender = c.s(5), kind = c.s(6), text = c.s(7),
                            fileId = c.s(8), uniqueId = c.s(9), thumbId = c.s(10), thumbUnique = c.s(11),
                            name = c.s(12), mime = c.s(13), duration = c.getInt(14), w = c.getInt(15),
                            h = c.getInt(16), size = c.getLong(17), stickerType = c.s(18),
                        )
                    )
                }
            }
        }

    @Synchronized
    fun markRead(chatId: Long) {
        writableDatabase.execSQL("UPDATE chats SET unread=0 WHERE id=? AND unread<>0", arrayOf<Any?>(chatId))
    }

    @Synchronized
    fun saveSticker(m: Msg) {
        writableDatabase.execSQL(
            "INSERT OR REPLACE INTO stickers(unique_id,file_id,thumb_id,thumb_unique,sticker_type,used) VALUES(?,?,?,?,?,?)",
            arrayOf<Any?>(m.uniqueId, m.fileId, m.thumbId, m.thumbUnique, m.stickerType, System.currentTimeMillis())
        )
    }

    @Synchronized
    fun stickers(): List<Sticker> =
        readableDatabase.rawQuery(
            "SELECT unique_id,file_id,thumb_id,thumb_unique,sticker_type FROM stickers ORDER BY used DESC LIMIT 200",
            null
        ).use { c ->
            buildList { while (c.moveToNext()) add(Sticker(c.s(0), c.s(1), c.s(2), c.s(3), c.s(4))) }
        }

    @Synchronized
    fun wipe() {
        val d = writableDatabase
        d.execSQL("DELETE FROM messages")
        d.execSQL("DELETE FROM chats")
        d.execSQL("DELETE FROM stickers")
    }
}
