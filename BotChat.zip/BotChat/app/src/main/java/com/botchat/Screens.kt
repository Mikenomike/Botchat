@file:OptIn(ExperimentalMaterial3Api::class)

package com.botchat

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ------------------------------------------------------------------- login

private val tokenRegex = Regex("\\d+:[A-Za-z0-9_-]+")

@Composable
fun LoginScreen() {
    var token by rememberSaveable { mutableStateOf("") }
    var base by rememberSaveable { mutableStateOf(DEFAULT_BASE) }
    var showToken by rememberSaveable { mutableStateOf(false) }
    var showAdvanced by rememberSaveable { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<Int?>(null) }
    val scope = rememberCoroutineScope()

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Spacer(Modifier.height(24.dp))
        Text(stringResource(R.string.login_title), fontSize = 24.sp, fontWeight = FontWeight.Bold)

        OutlinedTextField(
            value = token,
            onValueChange = { token = it.trim(); error = null },
            label = { Text(stringResource(R.string.token_hint)) },
            singleLine = true,
            visualTransformation = if (showToken) VisualTransformation.None else PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
            trailingIcon = {
                TextButton(onClick = { showToken = !showToken }) {
                    Text(stringResource(if (showToken) R.string.hide else R.string.show))
                }
            },
            modifier = Modifier.fillMaxWidth(),
        )

        TextButton(onClick = { showAdvanced = !showAdvanced }) {
            Text(stringResource(R.string.advanced))
        }
        if (showAdvanced) {
            OutlinedTextField(
                value = base,
                onValueChange = { base = it.trim() },
                label = { Text(stringResource(R.string.server_hint)) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                modifier = Modifier.fillMaxWidth(),
            )
            Text(
                stringResource(R.string.server_help),
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        error?.let { Text(stringResource(it), color = MaterialTheme.colorScheme.error) }

        Button(
            onClick = {
                if (!tokenRegex.matches(token)) {
                    error = R.string.err_token_format
                } else {
                    loading = true
                    error = null
                    scope.launch {
                        val r = Repo.login(token, base.ifEmpty { DEFAULT_BASE })
                        loading = false
                        when (r) {
                            LoginResult.INVALID -> error = R.string.err_invalid_token
                            LoginResult.NETWORK -> error = R.string.err_network_login
                            LoginResult.OK -> {}
                        }
                    }
                }
            },
            enabled = !loading && token.isNotEmpty(),
            modifier = Modifier.fillMaxWidth(),
        ) {
            if (loading) {
                CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
            } else {
                Text(stringResource(R.string.login_btn))
            }
        }

        Surface(
            color = MaterialTheme.colorScheme.surfaceVariant,
            shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
        ) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(stringResource(R.string.login_note), fontSize = 13.sp)
                Text(
                    stringResource(R.string.limits_note),
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

// --------------------------------------------------------------- chat list

private val avatarColors = listOf(
    Color(0xFFE17076), Color(0xFFEDA86C), Color(0xFFA695E7),
    Color(0xFF7BC862), Color(0xFF6EC9CB), Color(0xFF65AADD), Color(0xFFEE7AAE),
)

@Composable
fun Avatar(id: Long, title: String, size: Int = 48) {
    Box(
        Modifier
            .size(size.dp)
            .clip(CircleShape)
            .background(avatarColors[((id % 7) + 7).toInt() % 7]),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            title.trim().take(1).uppercase(),
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = (size * 0.42f).sp,
        )
    }
}

@Composable
fun kindLabel(kind: String, text: String): String {
    val label = when (kind) {
        "photo" -> "📷 " + stringResource(R.string.k_photo)
        "video" -> "🎬 " + stringResource(R.string.k_video)
        "voice" -> "🎙 " + stringResource(R.string.k_voice)
        "animation" -> "🖼 " + stringResource(R.string.k_gif)
        "sticker" -> "🙂 " + stringResource(R.string.k_sticker)
        "document" -> "📄 " + stringResource(R.string.k_file)
        "other" -> stringResource(R.string.unsupported)
        else -> return text
    }
    return if (text.isNotEmpty() && kind != "sticker") "$label, $text" else if (kind == "sticker") "$text $label" else label
}

@Composable
fun ChatListScreen(onOpen: (Long) -> Unit) {
    val tick by Repo.tick.collectAsState()
    val session by Repo.session.collectAsState()
    val pollError by Repo.pollError.collectAsState()
    var chats by remember { mutableStateOf(emptyList<Chat>()) }
    var menu by remember { mutableStateOf(false) }
    var confirmLogout by remember { mutableStateOf(false) }
    var showAdd by remember { mutableStateOf(false) }

    LaunchedEffect(tick) { chats = withContext(Dispatchers.IO) { Repo.db.chats() } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(session?.name.orEmpty().ifEmpty { "Bot" }, fontWeight = FontWeight.Bold)
                        val u = session?.username.orEmpty()
                        if (u.isNotEmpty()) Text("@$u", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                actions = {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, contentDescription = null) }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.remove_webhook)) },
                            onClick = { menu = false; Repo.removeWebhook() },
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.logout)) },
                            onClick = { menu = false; confirmLogout = true },
                        )
                    }
                },
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAdd = true }) {
                Icon(Icons.Default.Add, contentDescription = stringResource(R.string.add_chat))
            }
        },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            pollError?.let { e ->
                val msg = when (e) {
                    "net" -> stringResource(R.string.banner_net)
                    "conflict" -> stringResource(R.string.banner_conflict)
                    "auth" -> stringResource(R.string.banner_auth)
                    else -> e
                }
                Surface(color = MaterialTheme.colorScheme.errorContainer, modifier = Modifier.fillMaxWidth()) {
                    Text(msg, Modifier.padding(10.dp), fontSize = 13.sp, color = MaterialTheme.colorScheme.onErrorContainer)
                }
            }
            if (chats.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text(
                        stringResource(R.string.chats_empty),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(chats, key = { it.id }) { c ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { onOpen(c.id) }
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Avatar(c.id, c.title)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(c.title, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    kindLabel(c.lastKind, c.lastText),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            Spacer(Modifier.width(8.dp))
                            Column(horizontalAlignment = Alignment.End) {
                                Text(fmtChatTime(c.lastTs), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                if (c.unread > 0) {
                                    Spacer(Modifier.height(4.dp))
                                    Box(
                                        Modifier.clip(CircleShape).background(MaterialTheme.colorScheme.primary)
                                            .padding(horizontal = 7.dp, vertical = 2.dp)
                                    ) {
                                        Text(c.unread.toString(), color = Color.White, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (confirmLogout) {
        AlertDialog(
            onDismissRequest = { confirmLogout = false },
            text = { Text(stringResource(R.string.logout_confirm)) },
            confirmButton = {
                TextButton(onClick = { confirmLogout = false; Repo.logout() }) { Text(stringResource(R.string.logout)) }
            },
            dismissButton = {
                TextButton(onClick = { confirmLogout = false }) { Text(stringResource(R.string.cancel)) }
            },
        )
    }

    if (showAdd) {
        var input by remember { mutableStateOf("") }
        var failed by remember { mutableStateOf(false) }
        var working by remember { mutableStateOf(false) }
        val scope = rememberCoroutineScope()
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text(stringResource(R.string.add_chat)) },
            text = {
                Column {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it; failed = false },
                        label = { Text(stringResource(R.string.chat_id_hint)) },
                        singleLine = true,
                    )
                    if (failed) {
                        Text(stringResource(R.string.chat_not_found), color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = input.isNotBlank() && !working,
                    onClick = {
                        working = true
                        scope.launch {
                            val ok = Repo.addChat(input)
                            working = false
                            if (ok) showAdd = false else failed = true
                        }
                    },
                ) { Text(stringResource(R.string.add)) }
            },
            dismissButton = {
                TextButton(onClick = { showAdd = false }) { Text(stringResource(R.string.cancel)) }
            },
        )
    }
}
