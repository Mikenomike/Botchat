package com.botchat

import org.json.JSONObject

/**
 * kind: text | photo | video | animation | voice | sticker | document | other
 * For photos [fileId] is the largest size and [thumbId] a medium size used in the chat bubble.
 */
data class Msg(
    val rowId: Long = 0,
    val chatId: Long = 0,
    val msgId: Long = 0,
    val ts: Long = 0,
    val out: Boolean = false,
    val sender: String = "",
    val kind: String = "text",
    val text: String = "",
    val fileId: String = "",
    val uniqueId: String = "",
    val thumbId: String = "",
    val thumbUnique: String = "",
    val name: String = "",
    val mime: String = "",
    val duration: Int = 0,
    val w: Int = 0,
    val h: Int = 0,
    val size: Long = 0,
    val stickerType: String = "", // static | animated | video
)

data class Parsed(
    val msg: Msg,
    val chatTitle: String,
    val chatUsername: String,
    val chatType: String,
)

fun chatTitle(chat: JSONObject): String {
    val t = chat.optString("title")
    if (t.isNotEmpty()) return t
    val n = listOf(chat.optString("first_name"), chat.optString("last_name"))
        .filter { it.isNotEmpty() }.joinToString(" ")
    if (n.isNotEmpty()) return n
    val u = chat.optString("username")
    return if (u.isNotEmpty()) u else chat.optLong("id").toString()
}

private fun JSONObject.media(msg: Msg, kind: String): Msg {
    val th = optJSONObject("thumbnail") ?: optJSONObject("thumb")
    val len = optInt("length") // video notes
    return msg.copy(
        kind = kind,
        fileId = getString("file_id"),
        uniqueId = getString("file_unique_id"),
        thumbId = th?.optString("file_id").orEmpty(),
        thumbUnique = th?.optString("file_unique_id").orEmpty(),
        name = optString("file_name").ifEmpty { optString("title") },
        mime = optString("mime_type"),
        duration = optInt("duration"),
        w = if (len > 0) len else optInt("width"),
        h = if (len > 0) len else optInt("height"),
        size = optLong("file_size"),
    )
}

fun parseMessage(m: JSONObject, outgoing: Boolean): Parsed {
    val chat = m.getJSONObject("chat")
    val chatId = chat.getLong("id")
    val from = m.optJSONObject("from")
    val sender = when {
        from != null -> listOf(from.optString("first_name"), from.optString("last_name"))
            .filter { it.isNotEmpty() }.joinToString(" ")
            .ifEmpty { from.optString("username") }
        else -> m.optJSONObject("sender_chat")?.optString("title").orEmpty()
    }
    var msg = Msg(
        chatId = chatId,
        msgId = m.getLong("message_id"),
        ts = m.getLong("date") * 1000,
        out = outgoing,
        sender = sender,
        text = m.optString("text", m.optString("caption", "")),
    )

    val photos = m.optJSONArray("photo")
    val animation = m.optJSONObject("animation")
    val video = m.optJSONObject("video")
    val videoNote = m.optJSONObject("video_note")
    val voice = m.optJSONObject("voice")
    val audio = m.optJSONObject("audio")
    val sticker = m.optJSONObject("sticker")
    val doc = m.optJSONObject("document")

    when {
        photos != null && photos.length() > 0 -> {
            val big = photos.getJSONObject(photos.length() - 1)
            var mid = big
            for (i in 0 until photos.length()) {
                val o = photos.getJSONObject(i)
                if (o.optInt("width") >= 320) {
                    mid = o
                    break
                }
            }
            msg = msg.copy(
                kind = "photo",
                fileId = big.getString("file_id"),
                uniqueId = big.getString("file_unique_id"),
                thumbId = mid.getString("file_id"),
                thumbUnique = mid.getString("file_unique_id"),
                w = big.optInt("width"),
                h = big.optInt("height"),
                size = big.optLong("file_size"),
            )
        }
        animation != null -> msg = animation.media(msg, "animation")
        video != null -> msg = video.media(msg, "video")
        videoNote != null -> msg = videoNote.media(msg, "video")
        voice != null -> msg = voice.media(msg, "voice")
        audio != null -> msg = audio.media(msg, "voice")
        sticker != null -> {
            val type = when {
                sticker.optBoolean("is_video") -> "video"
                sticker.optBoolean("is_animated") -> "animated"
                else -> "static"
            }
            msg = sticker.media(msg, "sticker").copy(
                stickerType = type,
                text = sticker.optString("emoji"),
            )
        }
        doc != null -> msg = doc.media(msg, "document")
        msg.text.isEmpty() -> msg = msg.copy(kind = "other")
    }

    return Parsed(
        msg = msg,
        chatTitle = chatTitle(chat),
        chatUsername = chat.optString("username"),
        chatType = chat.optString("type"),
    )
}
