package com.botchat

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.Callback
import okhttp3.FormBody
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.Response
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

const val DEFAULT_BASE = "https://api.telegram.org"

class ApiError(val code: Int, message: String) : Exception(message)

data class Session(val token: String, val base: String, val name: String, val username: String)

class Upload(val field: String, val file: File, val name: String, val mime: String)

/** Thin client for the Telegram Bot API (https://core.telegram.org/bots/api). */
object Api {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(75, TimeUnit.SECONDS) // long polling uses timeout=30
        .writeTimeout(120, TimeUnit.SECONDS)
        .build()

    private suspend fun Call.await(): Response = suspendCancellableCoroutine { c ->
        c.invokeOnCancellation { cancel() }
        enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (c.isActive) c.resumeWithException(e)
            }

            override fun onResponse(call: Call, response: Response) {
                if (c.isActive) c.resume(response) else response.close()
            }
        })
    }

    suspend fun call(
        token: String,
        base: String,
        method: String,
        params: Map<String, String> = emptyMap(),
        upload: Upload? = null,
    ): JSONObject {
        val url = "${base.trimEnd('/')}/bot$token/$method"
        val body: RequestBody = if (upload == null) {
            val b = FormBody.Builder()
            params.forEach { (k, v) -> b.add(k, v) }
            b.build()
        } else {
            val b = MultipartBody.Builder().setType(MultipartBody.FORM)
            params.forEach { (k, v) -> b.addFormDataPart(k, v) }
            b.addFormDataPart(
                upload.field,
                upload.name,
                upload.file.asRequestBody(upload.mime.toMediaTypeOrNull())
            )
            b.build()
        }
        val resp = client.newCall(Request.Builder().url(url).post(body).build()).await()
        val code = resp.code
        val text = withContext(Dispatchers.IO) { resp.use { it.body?.string().orEmpty() } }
        val json = try {
            JSONObject(text)
        } catch (e: Exception) {
            throw IOException("Bad response ($code)")
        }
        if (!json.optBoolean("ok")) {
            throw ApiError(json.optInt("error_code", code), json.optString("description", "error"))
        }
        return json
    }

    suspend fun call(
        s: Session,
        method: String,
        params: Map<String, String> = emptyMap(),
        upload: Upload? = null,
    ): JSONObject = call(s.token, s.base, method, params, upload)

    /** Resolves [fileId] with getFile and downloads it to [dest] (Bot API limit: 20 MB). */
    suspend fun download(s: Session, fileId: String, dest: File) {
        val info = call(s, "getFile", mapOf("file_id" to fileId)).getJSONObject("result")
        val path = info.getString("file_path")
        val url = "${s.base.trimEnd('/')}/file/bot${s.token}/$path"
        val resp = client.newCall(Request.Builder().url(url).build()).await()
        withContext(Dispatchers.IO) {
            resp.use { r ->
                if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
                val tmp = File(dest.path + ".part")
                r.body!!.byteStream().use { input ->
                    tmp.outputStream().use { out -> input.copyTo(out) }
                }
                if (!tmp.renameTo(dest)) {
                    tmp.copyTo(dest, overwrite = true)
                    tmp.delete()
                }
            }
        }
    }
}
